export class Opcionesmenu {

   constructor(_id = '', idOpcionMenu = '', idMenu = '', url = '') {
        this._id = _id;
        this.idOpcionMenu = idOpcionMenu;
        this.idMenu = idMenu;
        this.url = url;
    }

    _id: string;
    idOpcionMenu: string;
    idMenu: string;
    url: string;
    




}
